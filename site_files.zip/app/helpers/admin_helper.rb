module AdminHelper

	def correct bool
		"correct" if bool
	end

end
