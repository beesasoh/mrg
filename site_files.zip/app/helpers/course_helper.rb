module CourseHelper
end
