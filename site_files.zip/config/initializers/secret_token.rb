# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Mrg::Application.config.secret_token = 'ef47fb6cfb7db74ae8ee80f7f538770d0925f60c4a3276b23c580ce09070c971ccd7624cdf7346f8c6d98c23955457a625fb7590f1943e7db8c93e8006154c5a'
