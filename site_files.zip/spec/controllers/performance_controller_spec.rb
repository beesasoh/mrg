require 'spec_helper'

describe PerformanceController do

end
