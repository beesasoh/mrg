require 'spec_helper'

describe UserController do

end
