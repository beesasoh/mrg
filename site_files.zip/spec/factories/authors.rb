# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :author do
    bio "he this is what i have done"
    email "beest@bee.com"
    name "Beesasoh Fredie"
  end
end
