# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :badge do
    name "badge1"
    description "Sample badge"
  end
end
