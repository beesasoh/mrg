# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :school do
    fb_id "MyString"
    name "MyString"
  end
end
