require 'spec_helper'

describe "rankings/week.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
