require 'test_helper'

class BookHelperTest < ActionView::TestCase
end
