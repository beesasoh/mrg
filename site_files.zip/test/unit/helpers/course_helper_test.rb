require 'test_helper'

class CourseHelperTest < ActionView::TestCase
end
