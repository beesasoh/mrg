require 'test_helper'

class PlayHelperTest < ActionView::TestCase
end
