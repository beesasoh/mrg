require 'test_helper'

class SocialHelperTest < ActionView::TestCase
end
